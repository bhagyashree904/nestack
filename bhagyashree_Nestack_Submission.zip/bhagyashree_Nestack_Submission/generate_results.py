"""Run sample queries through the API code path and write results.json.

Usage: python generate_results.py "query one" "query two" "query three"
"""
import json
import sys

from fastapi.testclient import TestClient

from server import app

DEFAULT_QUERIES = [
    "What is the main topic of this document?",
    "Summarise the key conclusions or findings",
    "What methods or approach are described?",
]

queries = sys.argv[1:] or DEFAULT_QUERIES
client = TestClient(app)
out = []
for q in queries:
    r = client.post("/query", json={"query": q, "top_k": 3})
    r.raise_for_status()
    out.append({"query": q, "top_k": 3, "results": r.json()})

with open("results.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote results.json with {len(out)} queries")
