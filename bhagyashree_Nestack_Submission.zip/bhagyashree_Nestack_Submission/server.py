"""Retrieval endpoint: direct similarity search, no LLM, no chains."""
from functools import lru_cache
from typing import List

from fastapi import FastAPI, HTTPException
from langchain_community.vectorstores import FAISS
from pydantic import BaseModel, Field

from config import INDEX_DIR, get_embeddings

app = FastAPI(title="PDF Vectorisation Retrieval API")


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(4, ge=1, le=50)


class Chunk(BaseModel):
    chunk_text: str
    page_number: int
    score: float


@lru_cache(maxsize=1)
def get_store() -> FAISS:
    return FAISS.load_local(
        INDEX_DIR, get_embeddings(), allow_dangerous_deserialization=True
    )


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/query", response_model=List[Chunk])
def query(req: QueryRequest):
    try:
        store = get_store()
    except Exception:
        raise HTTPException(503, "Index not found. Run: python ingest.py --file <pdf>")
    hits = store.similarity_search_with_score(req.query, k=req.top_k)
    return [
        Chunk(
            chunk_text=doc.page_content,
            page_number=int(doc.metadata.get("page", 0)) + 1,  # loader pages are 0-indexed
            score=float(score),  # FAISS L2 distance: lower = more similar
        )
        for doc, score in hits
    ]
