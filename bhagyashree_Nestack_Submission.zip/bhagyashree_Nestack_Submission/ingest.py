"""PDF ingestion as a LangGraph graph: load -> split -> embed -> store.

Usage:  python ingest.py --file document.pdf
"""
import argparse
import os
import sys
from typing import Any, List, TypedDict

from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langgraph.graph import END, START, StateGraph

from config import CHUNK_OVERLAP, CHUNK_SIZE, INDEX_DIR, get_embeddings


class IngestState(TypedDict, total=False):
    file_path: str
    pages: List[Document]
    chunks: List[Document]
    vectors: List[List[float]]
    stored: int


def load_node(state: IngestState) -> dict:
    pages = PyPDFLoader(state["file_path"]).load()
    print(f"[load]  {len(pages)} pages loaded")
    return {"pages": pages}


def split_node(state: IngestState) -> dict:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP
    )
    chunks = [c for c in splitter.split_documents(state["pages"]) if c.page_content.strip()]
    print(f"[split] {len(chunks)} chunks (size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP})")
    return {"chunks": chunks}


def embed_node(state: IngestState) -> dict:
    vectors = get_embeddings().embed_documents([c.page_content for c in state["chunks"]])
    print(f"[embed] {len(vectors)} vectors of dim {len(vectors[0])}")
    return {"vectors": vectors}


def store_node(state: IngestState) -> dict:
    chunks, vectors = state["chunks"], state["vectors"]
    store = FAISS.from_embeddings(
        text_embeddings=list(zip([c.page_content for c in chunks], vectors)),
        embedding=get_embeddings(),
        metadatas=[c.metadata for c in chunks],
    )
    store.save_local(INDEX_DIR)  # built-in persistence
    print(f"[store] saved {len(chunks)} chunks to '{INDEX_DIR}/'")
    return {"stored": len(chunks)}


def build_graph():
    g = StateGraph(IngestState)
    g.add_node("load", load_node)
    g.add_node("split", split_node)
    g.add_node("embed", embed_node)
    g.add_node("store", store_node)
    g.add_edge(START, "load")
    g.add_edge("load", "split")
    g.add_edge("split", "embed")
    g.add_edge("embed", "store")
    g.add_edge("store", END)
    return g.compile()


def main() -> int:
    ap = argparse.ArgumentParser(description="Ingest a PDF into a FAISS vector store")
    ap.add_argument("--file", required=True, help="path to the PDF")
    ap.add_argument("--graph", action="store_true", help="print graph nodes and diagram")
    args = ap.parse_args()

    if not os.path.isfile(args.file):
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    app = build_graph()
    if args.graph:
        print("Nodes:", [n for n in app.get_graph().nodes])
        print(app.get_graph().draw_mermaid())
    result = app.invoke({"file_path": args.file})
    print(f"Done. {result['stored']} chunks indexed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
