#!/bin/sh
# Build the index on first boot if missing, then serve.
if [ ! -d "${INDEX_DIR:-faiss_index}" ] && [ -f data/document.pdf ]; then
  python ingest.py --file data/document.pdf
fi
exec uvicorn server:app --host 0.0.0.0 --port "${PORT:-8000}"
