# PDF Vectorisation Pipeline (LangChain + LangGraph)

**Deployment link:** `<PASTE YOUR LIVE URL HERE>`  (try `<URL>/docs`)

Ingests a PDF into a FAISS vector store and serves raw similarity-search results over HTTP.
No LLM and no QA/RAG chains are used anywhere.

## Setup

```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 1. Ingest

Put the provided PDF at `data/document.pdf` (or use any path):

```bash
python ingest.py --file data/document.pdf
python ingest.py --file data/document.pdf --graph   # also prints node list + diagram
```

## 2. Run the retrieval server

```bash
uvicorn server:app --port 8000
```

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "your question", "top_k": 3}'
```

Response: `[{ "chunk_text": "...", "page_number": 1, "score": 0.42 }, ...]`
`score` is the FAISS L2 distance, so **lower means more similar**. `page_number` is 1-indexed.

## 3. Generate results.json

```bash
python generate_results.py "query 1" "query 2" "query 3"
```

## LangGraph ingestion graph

```
__start__ -> load -> split -> embed -> store -> __end__
```

Nodes: `['__start__', 'load', 'split', 'embed', 'store', '__end__']`

```mermaid
graph TD;
  __start__ --> load --> split --> embed --> store --> __end__;
```

## Component choices

| Stage | Choice | Why |
|---|---|---|
| Loader | `PyPDFLoader` | Pure Python, no system dependencies, one `Document` per page with a `page` metadata field, which gives the `page_number` the API needs. |
| Splitter | `RecursiveCharacterTextSplitter` (size 800, overlap 150) | Splits on paragraph, then sentence, then word boundaries, so chunks stay coherent. 800 chars (~150-200 tokens) is focused enough for precise matches yet holds a full idea; it also fits well within the embedding model's 512-token limit. 150 overlap (~19%) keeps sentences cut at a boundary retrievable from either side without much duplication. |
| Embeddings | `FastEmbedEmbeddings` (`BAAI/bge-small-en-v1.5`) | Free, runs locally with no API key, ONNX-based so it is light enough for free-tier hosting, and strong for its size on retrieval benchmarks. The same class and model are loaded in `config.py` for both ingest and query. |
| Vector store | `FAISS` | Fast local similarity search, persisted with the built-in `save_local()` / `load_local()`. `similarity_search_with_score()` is called directly on the store. |

## Deployment (Render / Railway / any Docker host)

The included `Dockerfile` installs dependencies, ingests `data/document.pdf` at build time, and starts the server.
Add the PDF to `data/document.pdf` before pushing, create a Web Service from the repo (Docker runtime), and put the resulting URL at the top of this README.

## Sample output

See `results.json` (generated from the provided PDF).
