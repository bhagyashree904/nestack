"""Shared settings. Ingestion and retrieval MUST use the same embedding model."""
import os

INDEX_DIR = os.getenv("INDEX_DIR", "faiss_index")
EMBED_MODEL = os.getenv("EMBED_MODEL", "BAAI/bge-small-en-v1.5")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "150"))


def get_embeddings():
    """Return the LangChain embedding integration used by both ingest and query."""
    if os.getenv("EMBEDDING_BACKEND") == "fake":  # offline smoke tests only
        from langchain_core.embeddings import DeterministicFakeEmbedding
        return DeterministicFakeEmbedding(size=384)
    from langchain_community.embeddings import FastEmbedEmbeddings
    return FastEmbedEmbeddings(model_name=EMBED_MODEL)
